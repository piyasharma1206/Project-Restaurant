<html>
<head>
    <title>Recipes - Tadka</title>
     <link rel="stylesheet" media="all" type="text/css" href="styles/stylesheet.css" />
    
     <link href="images/icon2.jpg" rel="shortcut icon" type="image/x-icon" >
    
</head>
<body class="recipes-page">
 <div class="page">
    <div class="container">
        <div class="top-menu-container">
            <ul class="top-right-menu">
                <li>
                    <a href="Pressroom.php" class="">Pressroom</a>
                </li>
                <li>
                    <a href="Careers.php" class="">Careers</a>
                </li>
                <li>
                    <a href="Contact Us.php" class="">Contact us</a>
                </li>
                <li>
                            <a href="admin.php" class="">Admin</a>
                </li>
            </ul>
        </div>
        <div class="menu-box">
            <div class="menu-container public-menu-container">

                <ul class="menu">
                    <li class="logo-container">
                        <a href="index.php" class="logo"><img src="images/icon2.jpg" alt="Tadka"/> </a>
                    </li>
                    <li class="menu-collapse">
                        <a href="#" class="explore-nav">Explore <span class="arrow"></span> </a>
                        <ul class="menu-dropdown">
                            <li><a href="Menu.php" class="text">Menu</a></li>
                            <li><a href="Locations.php" class="text">Locations</a></li>
                            <li><a href="Events.php" class="text">Events</a></li>
                            <li><a href="Our Story.php" class="text">Our Story</a></li>
                            <li><a href="Gallery.php" class="text">Gallery</a></li>
                            <li><a href="Recipe.php" class="text">Recipe</a></li>
                            <li><a href="Pressroom.php" class="text">Pressroom</a></li>
                            <li><a href="Careers.php" class="text">Careers</a></li>
                            <li>
                                <ul class="social-links">
                                    <li><a href="#" class="fb-social"></a></li>
                                    <li><a href="#" class="yt-social"></a></li>
                                    <li><a href="#" class="pin-social"></a></li>
                                    <li><a href="#" class="ig-social"></a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item ">
                         <a href="Menu.php" class="text">Menu</a>
                            <a class="menu-icon icon" href="Menu.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Locations.php" class="text">Locations</a>
                            <a class="locations-icon icon" href="Locations.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Events.php" class="text">Events</a>
                            <a class="events-icon icon" href="Events.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Our Story.php" class="text">Our Story</a>
                            <a class="our-story-icon icon" href="Our Story.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Gallery.php" class="text">Gallery</a>
                            <a class="gallery-icon icon" href="Gallery.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Recipe.php" class="text">Recipe</a>
                            <a class="recipe-icon icon" href="Recipe.php"></a>
                        </li>

                    <li>
                        <ul class="social-links">
                            <li><a href="#" class="fb-social"></a></li>
                            <li><a href="#" class="yt-social"></a></li>
                            <li><a href="#" class="pin-social"></a></li>
                            <li><a href="#" class="ig-social"></a></li>
                        </ul>
                    </li>
                </ul>
                <div class="search-box">
                    <div class="search-container">
                        <div class="search-heading">Locations close to you:</div>
                                                                        <div class="select-box" id="city-select">
                            <div class="select-overlay"><span class="default">City</span></div>
                            <div class="select-custom">
                                                                                                <span>Bangalore</span>                                                                <span>Punjab</span>                                                                <span>Delhi</span>                                                                <span>Jaipur</span>                                                                <span>Lucknow</span>                                                                <span>Chennai</span>                                                                <span>Hyderabad</span>                                                                <span>Kolkata</span>                                                                <span>Ahmedabad</span>                                                                <span>Baroda</span>                                                                <span>Mumbai</span>                                                                <span>Pune</span>                                                                <span>Surat</span>                                                                <span>Guwahati</span>                                                                <span>Coimbatore</span>                                                                <span>Panjim</span>                                                                <span>Visakhapatnam</span>                                                                <span>Raipur</span>                                                                <span>Mysuru</span>                                                                                            </div>
                        </div>
                        <div class="select-box" id="area-select">
                            <div class="select-overlay"><span class="default">Area</span></div>
                            <div class="select-custom">
                                                                <span class="no-item">Please select a city!</span>
                                                            </div>
                        </div>
                    </div>
                </div>
               
                <div class="recipe-container">
                    <a class="block-title" href="Recipe.php">Recipes</a>
                    <div class="home-recipe-intro">
                        We love food and we know that you love food too.
                        To help you discover the chef in you, we have dug into the recipe books of Tadka.
                        We share with you some of our favorite dishes, compliments of the chef!
                    </div>
                    <ul class="home-recipe-links">
                                                <li>
                                                    <a href="recipe1.php" class="recipe-link">Paneer Tikka Lazawab</a>
                        </li>
                                                <li>
                                                    <a href="recipe2.php" class="recipe-link">Coastal BBQ Prawns</a>
                        </li>
                                                <li>
                                                    <a href="recipe3.php" class="recipe-link">Dal Makhani</a>
                        </li>
                                                <li>
                                                    <a href="recipe4.php" class="recipe-link">Kadhai Paneer</a>
                        </li>
                                                <li>
                                                    <a class="currsive-link" href="Recipe.php">see all recipes<span class="link-arrow"></span></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    <div class="page-content">
            <h3 class="page-title">Recipes</h3>
    <div class="recipe-item">
        <img src="images/recipe icon 1.png" class="recipe-icon"/>        <img src="images/recipe 1.png" class="recipe-thumb"/>        <h4><a href="recipe1.php">PANEER TIKKA LAZAWAB</a></h4>
        <div class="meta">Difficulty: Average | Total Time: 45 mins | Makes: 4-5</div>
        <div class="description">
            Soft, Juicy chunks of paneer (cottage cheese) together with luscious capsicum, tomatoes and onions marinated in a heavenly Indian spice mix and grilled in a clay oven.        </div>
        <a href="paneer-tikka-lazawab.pdf" target="_blank" class="recipe-download">Download the recipe</a>
    </div>
    <div class="recipe-item">
        <img src="images/recipe icon 2.png" class="recipe-icon"/>        <img src="images/recipe 2.png" class="recipe-thumb"/>        <h4><a href="recipe2.php">COASTAL BBQ PRAWNS</a></h4>
        <div class="meta">Difficulty: Average | Total Time: 45 mins | Makes: 4-5</div>
        <div class="description">
            Char-grilled prawns marinated in a delectable mix of coastal spices and coconut cream.        </div>
        <a href="coastal-bbq-prawns.pdf" target="_blank" class="recipe-download">Download the recipe</a>
    </div>
    <div class="recipe-item">
        <img src="images/recipe icon 3.png" class="recipe-icon"/>        <img src="images/recipe 4.png" class="recipe-thumb"/>        <h4><a href="recipe3.php">DAL MAKHANI</a></h4>
        <div class="meta">Difficulty: Average | Total Time: 45 mins | Makes: 6-8</div>
        <div class="description">
            Black urad dal simmered slowly in a creamy blend of mild spices, butter and cream.        </div>
        <a href="dal-makhani.pdff" target="_blank" class="recipe-download">Download the recipe</a>
    </div>
    <div class="recipe-item">
        <img src="images/recipe icon 3.png" class="recipe-icon"/>        <img src="images/recipe 3.png" class="recipe-thumb"/>        <h4><a href="recipe4.php">KADHAI PANEER</a></h4>
        <div class="meta">Difficulty: Average | Total Time: 45 mins | Makes: 4-5</div>
        <div class="description">
            Paneer cubes come alive in an exotic blend of Indian spices and become the perfect accompaniment for savoury Naans and Parathas.        </div>
        <a href="kadhai-paneer.pdf" target="_blank" class="recipe-download">Download the recipe</a>
    </div>
    <div class="recipe-item">
        <img src="images/recipe icon 4.png" class="recipe-icon"/>        <img src="images/recipe 5.png" class="recipe-thumb"/>        <h4><a href="#5">KESARI PHIRNEE</a></h4>
        <div class="meta">Difficulty: Average | Total Time: 45 Minutes | Makes: 10-12</div>
        <div class="description">
            A traditional Indian creamy dessert accentuated with a hint of saffron and served chilled in terracotta pots.         </div>
        <a href="kesari-phirnee.pdf" target="_blank" class="recipe-download">Download the recipe</a>
    </div>
        </div>
    
 <div class="footer">
        <div class="container">
            <div class="message-box">
                     <h4>Send us a quick message</h4>

                     <form method="post" action="Our Story.php" id="contact-form">
                <input type="text" placeholder="Full Name" name="full_name"/> 
                <input type="text" placeholder="Email Id" name="email"/> 
                <input type="text" placeholder="Your Message" class="message" name="message"/>
                <input type="submit" value="Submit">
           </form> 
       </div> 
            <ul class="footer-menu">
                <li><a href="Menu.php">Menu</a></li>
                <li><a href="Locations.php">Locations</a></li>
                <li><a href="Events.php">Events</a></li>
                <li><a href="About Us.php">About us</a></li>
                <li><a href="Gallery.php">Gallery</a></li>
                <li><a href="Recipe.php">Recipes</a></li>
                <li><a href="Pressroom.php">Press</a></li>
                <li><a href="Careers.php">Careers</a></li>
                <li><a href="Contact Us.php">Contact us</a></li>
            </ul>
        </div>
        <div class="footer-flame"></div>
    </div>
    
    
</body>
</html>
    



            
