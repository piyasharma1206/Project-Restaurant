<html>
<head>
    <title>Contact us - Restaurant</title>
    <link media="all" type="text/css" rel="stylesheet" href="styles/stylesheet.css">
    <link href="images/icon2.jpg" rel="shortcut icon" type="image/x-icon" >
</head>
<body class="white-page">
    
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-5H4DXX"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<script>
    (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5H4DXX');
</script>

<div class="page">
    <div class="container">
        <div class="top-menu-container">
            <ul class="top-right-menu">
                <li>
                    <a href="Pressroom.php" class="">Pressroom</a>
                </li>
                <li>
                    <a href="Careers.php" class="active">Careers</a>
                </li>
                <li>
                    <a href="Contact.php" class="">Contact us</a>
                </li>
            </ul>
        </div>
        <div class="menu-box">
            <div class="menu-container public-menu-container">

                <ul class="menu">
                    <li class="logo-container">
                        <a href="index.php" class="logo"><img src="images/icon.jpg" alt="Restaurant"/> </a>
                    </li>
                    <li class="menu-collapse">
                        <a href="#" class="explore-nav">Explore <span class="arrow"></span> </a>
                        <ul class="menu-dropdown">
                            <li><a href="Menu.php" class="text">Menu</a></li>
                            <li><a href="Locations.php" class="text">Locations</a></li>
                            <li><a href="Events.php" class="text">Events</a></li>
                            <li><a href="Our Story.php" class="text">Our Story</a></li>
                            <li><a href="Gallery.php" class="text">Gallery</a></li>
                            <li><a href="Recipe.php" class="text">Recipe</a></li>
                            <li><a href="Pressroom.php" class="text">Pressroom</a></li>
                            <li><a href="Careers.php" class="text">Careers</a></li>
                            <li>
                                <ul class="social-links">
                                    <li><a href="#" class="fb-social"></a></li>
                                    <li><a href="#" class="yt-social"></a></li>
                                    <li><a href="#" class="pin-social"></a></li>
                                    <li><a href="#" class="ig-social"></a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item ">
                        <a href="Menu.php" class="text">Menu</a>
                        <a class="menu-icon icon" href="#"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Locations.php" class="text">Locations</a>
                        <a class="locations-icon icon" href="#"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Events.php" class="text">Events</a>
                        <a class="events-icon icon" href="#"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Our Story.php" class="text">Our Story</a>
                        <a class="our-story-icon icon" href="Our Story.php"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Gallery.php" class="text">Gallery</a>
                        <a class="gallery-icon icon" href="Gallery.php"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Recipe.php" class="text">Recipe</a>
                        <a class="recipe-icon icon" href="Recipe.php"></a>
                    </li>

                    <li>
                        <ul class="social-links">
                            <li><a href="#" class="fb-social"></a></li>
                            <li><a href="#" class="yt-social"></a></li>
                            <li><a href="#" class="pin-social"></a></li>
                            <li><a href="#" class="ig-social"></a></li>
                        </ul>
                    </li>
                </ul>
                <div class="search-box">
                    <div class="search-container">
                        <div class="search-heading">Locations close to you:</div>
                                                                        <div class="select-box" id="city-select">
                            <div class="select-overlay"><span class="default">City</span></div>
                            <div class="select-custom">
                                                                                                <span>Bangalore</span>                                                                <span>Punjab</span>                                                                <span>Delhi</span>                                                                <span>Jaipur</span>                                                                <span>Lucknow</span>                                                                <span>Chennai</span>                                                                <span>Hyderabad</span>                                                                <span>Kolkata</span>                                                                <span>Ahmedabad</span>                                                                <span>Baroda</span>                                                                <span>Mumbai</span>                                                                <span>Pune</span>                                                                <span>Surat</span>                                                                <span>Guwahati</span>                                                                <span>Coimbatore</span>                                                                <span>Panjim</span>                                                                <span>Visakhapatnam</span>                                                                <span>Raipur</span>                                                                <span>Mysuru</span>                                                                                            </div>
                        </div>
                        <div class="select-box" id="area-select">
                            <div class="select-overlay"><span class="default">Area</span></div>
                            <div class="select-custom">
                                                                <span class="no-item">Please select a city!</span>
                                                            </div>
                        </div>
                    </div>
                </div>
                <div class="gallery-container">
                    <a class="block-title" href="Gallery.php">Gallery</a>
                    <div class="sidebar-gallery-image">
                        <img src="#"/>
                    </div>
                </div>
                <div class="recipe-container">
                    <a class="block-title" href="Recipe.php">Recipes</a>
                    <div class="home-recipe-intro">
                        We love food and we know that you love food too.
                        To help you discover the chef in you, we have dug into the recipe books of Tadka.
                        We share with you some of our favorite dishes, compliments of the chef!
                    </div>
                    <ul class="home-recipe-links">
                                                <li>
                                                    <a href="recipe1.php" class="recipe-link">Paneer Tikka Lazawab</a>
                        </li>
                                                <li>
                                                    <a href="recipe2.php" class="recipe-link">Coastal BBQ Prawns</a>
                        </li>
                                                <li>
                                                    <a href="recipe3.php" class="recipe-link">Dal Makhani</a>
                        </li>
                                                <li>
                                                    <a href="recipe4.php" class="recipe-link">Kadhai Paneer</a>
                        </li>
                                                <li>
                            <a class="currsive-link" href="Recipe.php">see all recipes<span class="link-arrow"></span></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-content">
            <h3 class="page-title white-title">Contact us</h3>
<div class="content">
    <h2>Franchise Enquiry</h2>

<p>Tadkan does not operate on the franchise model.</p>

<h2>Feedback</h2>

<p>Have a suggestion, complaint or compliment? We&rsquo;d love to hear from you. Mail us at <a href="mailto:piyasharma1206@gmail.com">piyasharma1206@gmail.com</a></p>

<h2>Enquiries</h2>

<p>Have a question? Mail <a href="mailto:piyasharma1206@gmail.com">piyasharma1206@gmail.com</a> and we&rsquo;ll get back to you immediately.</p>

<h2>Careers</h2>

<p>Want to work with us? Mail <a href="mailto:piyasharma1206@gmail.com">piyasharma1206@gmail.com</a> to start your journey with Tadka.</p>



</div>
        </div>
    </div>
</div>

<div class="footer">
    <div class="container">
<div class="message-box">
                     <h4>Send us a quick message</h4>

            <form method="post" action="#" id="contact-form">
                <input type="text" placeholder="Full Name" name="full_name"/> 
                <input type="text" placeholder="Email Id" name="email"/> 
                <input type="text" placeholder="Your Message" class="message" name="message"/>
                <input type="submit" value="Submit">
           </form> 
       </div> 
        <ul class="footer-menu">
            <<li><a href="Menu.php">Menu</a></li>
            <li><a href="Locations.php">Locations</a></li>
            <li><a href="Events.php">Events</a></li>
            <li><a href="About Us.php">About us</a></li>
            <li><a href="Gallery.php">Gallery</a></li>
            <li><a href="Recipe.php">Recipes</a></li>
            <!--            <li><a href="#">Contact</a></li>-->
            <li><a href="Press.php">Press</a></li>
            <li><a href="Careers.php">Careers</a></li>
            <li><a href="Contact Us.php">Contact us</a></li>
        </ul>
    </div>
    <div class="footer-flame"></div>
</div>
</body>
</html>