<html>
<head>
    <title>Tadka</title>
    
    <link rel="stylesheet" media="all" type="text/css" href="styles/stylesheet.css" />
    <link href="images/icon2.jpg" rel="shortcut icon" type="image/x-icon" >
    
</head>
<body class="home-body">
    
    <div class="home-intro">
        <div class="home-intro-bg">
            <div class="container">
                <div class="top-menu-container">
                    <ul class="top-right-menu">
                        <li>
                            <a href="Pressroom.php" class="">Pressroom</a>
                        </li>
                        <li>
                            <a href="Careers.php" class="">Careers</a>
                        </li>
                        <li>
                            <a href="Contact Us.php" class="">Contact Us</a>
                        </li>
                        <li>
                            <a href="admin.php" class="">Admin</a>
                        </li>
                    </ul>
                </div>
                <div class="menu-container">
                    <ul class="menu">
                        <li class="logo-container">
                            <a href="index.php" class="logo"><img src="images/icon.jpg" alt="Restaurant"/> </a>
                        </li>
                        <li class="menu-collapse">
                            <a href="#" class="explore-nav">Explore <span class="arrow"></span> </a>
                            <ul class="menu-dropdown">
                                <li id="menu_id"><a href="Menu.php" class="text">Menu</a></li>
                                <li id="location_id"><a href="Locations.php" class="text">Locations</a></li>
                                <li id="events_id"><a href="Events.php" class="text">Events</a></li>
                                <li id="story_id"><a href="Our Story.php" class="text">Our Story</a></li>
                                <li id="gallery_id"><a href="Gallery.php" class="text">Gallery</a></li>
                                <li id="recipe_id"><a href="Recipe.php" class="text">Recipe</a></li>
                                <li id="pressroom_id"><a href="Pressroom.php" class="text">Pressroom</a></li>
                                <li id="career_id"><a href="Careers.php" class="text">Careers</a></li>
                                <li>
                                    <ul class="social-links">
                                        <li><a href="#" class="fb-social"></a></li>
                                        <li><a href="#" class="yt-social"></a></li>
                                        <li><a href="#" class="pin-social"></a></li>
                                        <li><a href="#" class="ig-social"></a></li>                                     
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="menu-item ">
                            <a href="Menu.php" class="text">Menu</a>
                            <a class="menu-icon icon" href="Menu.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Locations.php" class="text">Locations</a>
                            <a class="locations-icon icon" href="Locations.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Events.php" class="text">Events</a>
                            <a class="events-icon icon" href="Events.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Our Story.php" class="text">Our Story</a>
                            <a class="our-story-icon icon" href="Our Story.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Gallery.php" class="text">Gallery</a>
                            <a class="gallery-icon icon" href="Gallery.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Recipe.php" class="text">Recipe</a>
                            <a class="recipe-icon icon" href="Recipe.php"></a>
                        </li>
                        <li>
                            <ul class="social-links">
                                <li><a href="#" class="fb-social"></a></li>
                                <li><a href="#" class="yt-social"></a></li>
                                <li><a href="#" class="pin-social"></a></li>
                                <li><a href="#" class="ig-social"></a></li>
                            </ul>
                        </li>
                    </ul>
                    <div class="menu-slider home-page-small-slider">
                        <div class="image-slider" id="small-slider-box">
                               
                        </div>
                    </div>
                    <div class="search-container">
                        <div class="search-heading">Locations close to you:</div>
                        <div class="select-box" id="city-select">
                            <div class="select-overlay"><span class="default">City</span></div>
                            <div class="select-custom">
                                <span>Bangalore</span> 
                                <span>Punjab</span> 
                                <span>Delhi</span> 
                                <span>Jaipur</span>
                                <span>Lucknow</span> 
                                <span>Chennai</span> 
                                <span>Hyderabad</span>
                                <span>Kolkata</span> 
                                <span>Ahmedabad</span>
                                <span>Baroda</span>  
                                <span>Mumbai</span>
                                <span>Pune</span>  
                                <span>Surat</span>
                                <span>Guwahati</span>                            
                                <span>Coimbatore</span>
                                <span>Panjim</span> 
                                <span>Visakhapatnam</span>
                            </div>
                        </div>
                        <div class="select-box" id="area-select">
                            <div class="select-overlay"><span class="default">Area</span></div>
                            <div class="select-custom">
                                <span class="no-item">Please select a city!</span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                $sqlconnect=  mysql_connect("localhost","root","root");
                mysql_select_db("tadka",$sqlconnect);
                
                $query = "SELECT name,email,message FROM message";
                
                $result=mysql_query($query);
                echo "<table border='1px' cellpadding='10'>";
                
                while($sqlr=  mysql_fetch_array($result)){
                     
                    
            echo "<tr>";
               echo " <td><pre>".$sqlr['name']. "   ". " </pre></td>";
               echo " <td><pre>" .$sqlr['email']. "   ". "</pre></td>";
                echo "<td><pre>" .$sqlr['message']. "   ". "</pre></td>";
            echo "</tr>";
            echo"</br></br>";
                }
                       echo " </table>";
                       
                       mysql_close();

                ?>
            </div>
        </div>
    </div>
    <div class="home-content">
        <div class="container">
            <div class="home-gallery gallery">
                <a class="block-title" href="Gallery.php">Gallery</a>
                    <div class="gallery-inner">
                        <ul class="bxslider" id="locations-page-slider" class="bxslider">
                            <li>
                                <div class="slide">
                                    <img src="images/gallery image 1.jpg" />
                                    <div class="pin-box">
                                        <a class="pinterest" href="#" onclick="window.open(this.href); return false;"><img src="#"/> </a>
                                    </div>
                                    <div class="slide-caption">Batata nu shaak</div>
                                    <span class="icon-container">
                                        <img src="#" class="icon"/>
                                        <span class="icon-overlay"></span>
                                    </span>
                                </div>
                            </li>
                            </ul>
                    </div>
                </div>
                <div class="home-recipes">
                    <a class="block-title" href="Recipe.php">Recipes</a>

                    <div class="home-recipe-intro">
                        We love food and we know that you love food too.
                        To help you discover the chef in you, we have dug into the recipe books of Tadka.
                        We share with you some of our favorite dishes, compliments of the chef!
                    </div>
                    <ul class="home-recipe-links">
                        <li>
                            <a href="recipe1.php" class="recipe-link">Paneer Tikka Lazawab</a>
                        </li>
                        <li>
                            <a href="recipe2.php" class="recipe-link">Coastal Prawns</a>
                        </li>
                        <li>
                            <a href="recipe3.php" class="recipe-link">Dal Makhani</a>
                        </li>
                        <li>
                            <a href="recipe4.php" class="recipe-link">Kadhai Paneer</a>
                        </li>
                        <li>
                            <a class="currsive-link" href="Recipe.php">see all recipes<span class="link-arrow"></span></a>
                        </li>
                    </ul>
                </div>
                <span class="clear-fix"></span>
            </div>
    </div>
    <div class="coming-soon">
        <div class="cs-left"></div>
            <div class="cs-box">

                <div class="cs-text">ATR TOWERS, VISAKHAPATNAM<BR />
                                     HABITAT MALL, MYSURU<BR />
                                     MAGNETO MALL, RAIPUR<BR />
                                     PARK STREET, KOLKATA</div>
            </div>
            <div class="cs-right">
            </div>
    </div>
    <div class="footer">
        <div class="container">
            <div class="message-box">
                     <h4>Send us a quick message</h4>

                     <form method="post" action="Our Story.php" id="contact-form">
                <input type="text" placeholder="Full Name" name="full_name"/> 
                <input type="text" placeholder="Email Id" name="email"/> 
                <input type="text" placeholder="Your Message" class="message" name="message"/>
                <input type="submit" value="Submit">
           </form> 
       </div> 
            <ul class="footer-menu">
                <li><a href="Menu.php">Menu</a></li>
                <li><a href="Locations.php">Locations</a></li>
                <li><a href="Events.php">Events</a></li>
                <li><a href="About Us.php">About us</a></li>
                <li><a href="Gallery.php">Gallery</a></li>
                <li><a href="Recipe.php">Recipes</a></li>
                <li><a href="Pressroom.php">Press</a></li>
                <li><a href="Careers.php">Careers</a></li>
                <li><a href="Contact Us.php">Contact us</a></li>
            </ul>
        </div>
        <div class="footer-flame"></div>
    </div>
    
    
</body>
</html>
    



            

            
                

                            
                          
                            
                        