
<html>
<head>
    <title>Careers - Restaurant</title>
    <link media="all" type="text/css" rel="stylesheet" href="styles/stylesheet.css">
    <link href="images/icon2.jpg" rel="shortcut icon" type="image/x-icon" >
</head>
<body class="careers-page white-page">
<div class="page">
    <div class="container">
        <div class="top-menu-container">
            <ul class="top-right-menu">
                <li>
                    <a href="Pressroom.php" class="">Pressroom</a>
                </li>
                <li>
                    <a href="Careers.php" class="active">Careers</a>
                </li>
                <li>
                    <a href="Contact.php" class="">Contact us</a>
                </li>
            </ul>
        </div>
        <div class="menu-box">
            <div class="menu-container public-menu-container">

                <ul class="menu">
                    <li class="logo-container">
                    
                        <a href="index.php" class="logo"><img src="images/icon.jpg" alt="Restaurant"/> </a>
                    </li>
                    <li class="menu-collapse">
                        <a href="#" class="explore-nav">Explore <span class="arrow"></span> </a>
                        <ul class="menu-dropdown">
                            <li><a href="Menu.php" class="text">Menu</a></li>
                            <li><a href="Locations.php" class="text">Locations</a></li>
                            <li><a href="Events.php" class="text">Events</a></li>
                            <li><a href="Our Story.php" class="text">Our Story</a></li>
                            <li><a href="Gallery.php" class="text">Gallery</a></li>
                            <li><a href="Recipe.php" class="text">Recipe</a></li>
                            <li><a href="Pressroom.php" class="text">Pressroom</a></li>
                            <li><a href="Careers.php" class="text">Careers</a></li>
                                                        <li>
                                <ul class="social-links">
                                    <li><a href="#" class="fb-social"></a></li>
                                    <li><a href="#" class="yt-social"></a></li>
                                    <li><a href="#" class="pin-social"></a></li>
                                    <li><a href="#" class="ig-social"></a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item ">
                        <a href="Menu.php" class="text">Menu</a>
                        <a class="menu-icon icon" href="#"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Locations.php" class="text">Locations</a>
                        <a class="locations-icon icon" href="#"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Events.php" class="text">Events</a>
                        <a class="events-icon icon" href="#"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Our Story.php" class="text">Our Story</a>
                        <a class="our-story-icon icon" href="Our Story.php"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Gallery.php" class="text">Gallery</a>
                        <a class="gallery-icon icon" href="Gallery.php"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Recipe.php" class="text">Recipe</a>
                        <a class="recipe-icon icon" href="Recipe.php"></a>
                    </li>

                    <li>
                        <ul class="social-links">
                            <li><a href="#" class="fb-social"></a></li>
                            <li><a href="#" class="yt-social"></a></li>
                            <li><a href="#" class="pin-social"></a></li>
                            <li><a href="#" class="ig-social"></a></li>
                        </ul>
                    </li>
                </ul>
                <div class="search-box">
                    <div class="search-container">
                        <div class="search-heading">Locations close to you:</div>
                                                                        <div class="select-box" id="city-select">
                            <div class="select-overlay"><span class="default">City</span></div>
                            <div class="select-custom">
                                <span>Bangalore</span> 
                                <span>Punjab</span>
                                <span>Delhi</span>
                                <span>Jaipur</span>
                                <span>Lucknow</span>
                                <span>Chennai</span>
                                <span>Hyderabad</span>
                                <span>Kolkata</span>
                                <span>Ahmedabad</span> 
                                <span>Baroda</span> 
                                <span>Mumbai</span>  
                                <span>Pune</span> 
                                <span>Surat</span>  
                                <span>Guwahati</span> 
                                <span>Coimbatore</span> 
                                <span>Panjim</span>   
                                <span>Visakhapatnam</span>
                            </div>
                        </div>
                        <div class="select-box" id="area-select">
                            <div class="select-overlay"><span class="default">Area</span></div>
                            <div class="select-custom">
                                <span class="no-item">Please select a city!</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="gallery-container">
                    <a class="block-title" href="Gallery.php">Gallery</a>
                    <div class="sidebar-gallery-image">
                        <img src="#"/>
                    </div>
                </div>
                <div class="recipe-container">
                    <a class="block-title" href="Recipe.php">Recipes</a>
                    <div class="home-recipe-intro">
                        We love food and we know that you love food too.
                        To help you discover the chef in you, we have dug into the recipe books of Tadka.
                        We share with you some of our favorite dishes, compliments of the chef!
                    </div>
                    <ul class="home-recipe-links">
                                                <li>
                                                    <a href="recipe1.php" class="recipe-link">Paneer Tikka Lazawab</a>
                        </li>
                                                <li>
                                                    <a href="recipe2.php" class="recipe-link">Coastal BBQ Prawns</a>
                        </li>
                                                <li>
                                                    <a href="recipe3.php" class="recipe-link">Dal Makhani</a>
                        </li>
                                                <li>
                                                    <a href="recipe4.php" class="recipe-link">Kadhai Paneer</a>
                        </li>
                                                <li>
                                                    <a class="currsive-link" href="Recipe.php">see all recipes<span class="link-arrow"></span></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-content">
            <h3 class="page-title">Careers</h3>

<div class="content">
    <div class="career-intro">
        <p>
            We are one of the fastest growing restaurant chains in India – 42 outlets across the country.
            We are present in all major cities in India and are now going into the tier two cities. Another 35 stores are
            planned by 2016. Though we are relatively young we have evolved a work ethos that is designed to delight each
            and every customer. We are determined to bring a healthy dose of warmth and cheer to our service levels and make
            the customers’ Tadka experience truly unforgettable.
        </p>
        <p>
            Our training programs are designed to equip you with the right skills and attitude required for a career in the
            hospitality sector. We also believe in promoting from within, and given our aggressive expansion plans, your
            career can take wings if you have the right commitment and attitude.
        </p>
    </div>
    <div class="career-openings">
        <p>The positions that are open are listed below.</p>

        <div class="select-box" id="job-select">
            <div class="select-overlay"><span class="default">Search by city</span></div>
            <div class="select-custom">
                <span>All cities</span>
                <span>Bangalore</span>
                <span>Jaipur</span>
                <span>Nagpur</span>
            </div>
        </div>
                <div class="career-collapse">
            <div href="#" class="career-title">
                <span>Bartenders</span>
                <a href="mailto:piyasharma1206@gmail.com?Subject=Bartenders" target="_blank" class="jobs-apply">
                    Apply
                </a>
            </div>

            <div class="career-content">
                <h5>Responsibilities</h5>

                <p>Preparation of beverages, both alcoholic and non-alcoholic. The candidate must be a skilled entertainer and mixologist.</p>

                <h5>Qualifications:</h5>

                <p>Candidates must be skilled in fire flaring, with 3-5 years of experience and a background in BHM or other bartending courses.</p>
            </div>
        </div>
                <div class="career-collapse">
            <div href="#" class="career-title">
                <span>Cuisine Chef</span>
                <a href="mailto:mailto:piyasharma1206@gmail.com?Subject=Cuisine Chef" target="_blank" class="jobs-apply">
                    Apply
                </a>
            </div>

            <div class="career-content">
                <h5>Responsibilities</h5>

                <p>This position is responsible for overseeing all culinary functions for a corporate dining account. You will manage and lead a team of associates and oversee all safety and sanitation as it pertains to the account. Additionally, as part of the culinary team, you will be responsible for the following:</p>

                <h5>Qualifications:</h5>

                <p>Culinary degree preferred.Three to five years of culinary management experience.High volume production and catering experience is essential.Previous experience managing cost controls.Desire to learn and grow with a top notch foodservice company.</p>
            </div>
        </div>
                <div class="career-collapse">
            <div href="#" class="career-title">
                <span>Cuisine Chef</span>
                <a href="mailto:mailto:piyasharma1206@gmail.com?Subject=Cuisine Chef" target="_blank" class="jobs-apply">
                    Apply
                </a>
            </div>

            <div class="career-content">
                <h5>Responsibilities</h5>

                <p>This position is responsible for overseeing all culinary functions for a corporate dining account. You will manage and lead a team of associates and oversee all safety and sanitation as it pertains to the account. Additionally, as part of the culinary team, you will be responsible for the following:</p>

                <h5>Qualifications:</h5>

                <p>Culinary degree preferred.Three to five years of culinary management experience.High volume production and catering experience is essential.Previous experience managing cost controls.Desire to learn and grow with a top notch foodservice company.</p>
            </div>
        </div>
                <div class="career-collapse">
            <div href="#" class="career-title">
                <span>Executive chef</span>
                <a href="mailto:mailto:piyasharma1206@gmail.com?Subject=Executive chef" target="_blank" class="jobs-apply">
                    Apply
                </a>
            </div>

            <div class="career-content">
                <h5>Responsibilities</h5>

                <p>This position is responsible for overseeing all culinary functions for a corporate dining account. You will manage and lead a team of associates and oversee all safety and sanitation as it pertains to the account. Additionally, as part of the culinary team, you will be responsible for the following:</p>

                <h5>Qualifications:</h5>

                <p>Culinary degree preferred.Three to five years of culinary management experience.High volume production and catering experience is essential.Previous experience managing cost controls.Desire to learn and grow with a top notch foodservice company.</p>
            </div>
        </div>
                <div class="career-collapse">
            <div href="#" class="career-title">
                <span>Captain</span>
                <a href="mailto:mailto:piyasharma1206@gmail.com?Subject=Captain" target="_blank" class="jobs-apply">
                    Apply
                </a>
            </div>

            <div class="career-content">
                <h5>Responsibilities</h5>

                <p><p>This position is responsible for overseeing all culinary functions for a corporate dining account. You will manage and lead a team of associates and oversee all safety and sanitation as it pertains to the account. Additionally, as part of the culinary team, you will be responsible for the following:</p></p>

                <h5>Qualifications:</h5>

                <p><p>Culinary degree preferred.<br />Three to five years of culinary management experience.<br />High volume production and catering experience is essential.<br />Previous experience managing cost controls.<br />Desire to learn and grow with a top notch foodservice company.</p></p>
            </div>
        </div>
        
    </div>
</div>
<script type="text/javascript">
    var careerBaseURL="Careers.php";
</script>
        </div>
    </div>
</div>

<div class="footer">
    <div class="container">
<div class="message-box">
                     <h4>Send us a quick message</h4>

            <form method="post" action="#" id="contact-form">
                <input type="text" placeholder="Full Name" name="full_name"/> 
                <input type="text" placeholder="Email Id" name="email"/> 
                <input type="text" placeholder="Your Message" class="message" name="message"/>
                <input type="submit" value="Submit">
           </form> 
       </div> 
        <ul class="footer-menu">
            <li><a href="Menu.php">Menu</a></li>
            <li><a href="Locations.php">Locations</a></li>
            <li><a href="Events.php">Events</a></li>
            <li><a href="About Us.php">About us</a></li>
            <li><a href="Gallery.php">Gallery</a></li>
            <li><a href="Recipe.php">Recipes</a></li>
            <!--            <li><a href="#">Contact</a></li>-->
            <li><a href="Press.php">Press</a></li>
            <li><a href="Careers.php">Careers</a></li>
            <li><a href="Contact Us.php">Contact us</a></li>
        </ul>
    </div>
    <div class="footer-flame"></div>
</div>
</body>
</html>