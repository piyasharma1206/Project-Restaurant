<html>
<head>
    <title>Mains Menu - Restaurant</title>
    <link media="all" type="text/css" rel="stylesheet" href="styles/stylesheet.css">
    <link href="images/icon2.jpg" rel="shortcut icon" type="image/x-icon" >
        
</head>
<body class="menu-page">
<div class="page">
    <div class="container">
        <div class="top-menu-container">
            <ul class="top-right-menu">
                <li>
                    <a href="Pressroom.php" class="">Pressroom</a>
                </li>
                <li>
                    <a href="Careers.php" class="">Careers</a>
                </li>
                <li>
                    <a href="Contact Us.php" class="">Contact us</a>
                </li>
            </ul>
        </div>
        <div class="menu-box">
            <div class="menu-container public-menu-container">

                <ul class="menu">
                    <li class="logo-container">
                        <a href="index.php" class="logo"><img src="images/icon.jpg" alt="restaurant"/> </a>
                    </li>
                    <li class="menu-collapse">
                        <a href="#" class="explore-nav">Explore <span class="arrow"></span> </a>
                        <ul class="menu-dropdown">
                            <li><a href="Menu.php" class="text">Menu</a></li>
                            <li><a href="Locations.php" class="text">Locations</a></li>
                            <li><a href="Events.php" class="text">Events</a></li>
                            <li><a href="Our Story.php" class="text">Our Story</a></li>
                            <li><a href="Gallery.php" class="text">Gallery</a></li>
                            <li><a href="Recipe.php" class="text">Recipe</a></li>
                            <li><a href="Pressroom.php" class="text">Pressroom</a></li>
                            <li><a href="Careers.php" class="text">Careers</a></li>
                           <li>
                                <ul class="social-links">
                                    <li><a href="#" class="fb-social"></a></li>
                                    <li><a href="#" class="yt-social"></a></li>
                                    <li><a href="#" class="pin-social"></a></li>
                                    <li><a href="#" class="ig-social"></a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item ">
                        <a href="Menu.php" class="text">Menu</a>
                        <a class="menu-icon icon" href="Menu.php"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Locations.php" class="text">Locations</a>
                        <a class="locations-icon icon" href="Locations.php"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Events.php" class="text">Events</a>
                        <a class="events-icon icon" href="Events.php"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Our Story.php" class="text">Our Story</a>
                        <a class="our-story-icon icon" href="Our Story.php"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Gallery.php" class="text">Gallery</a>
                        <a class="gallery-icon icon" href="Gallery.php"></a>
                    </li>
                    <li class="menu-item ">
                        <a href="Recipe.php" class="text">Recipe</a>
                        <a class="recipe-icon icon" href="Recipe.php"></a>
                    </li>

                    <li>
                        <ul class="social-links">
                            <li><a href="#" class="fb-social"></a></li>
                            <li><a href="#" class="yt-social"></a></li>
                            <li><a href="#" class="pin-social"></a></li>
                            <li><a href="#" class="ig-social"></a></li>
                        </ul>
                    </li>
                </ul>
                <div class="search-box">
                    <div class="search-container">
                        <div class="search-heading">Locations close to you:</div>
                                                                        <div class="select-box" id="city-select">
                            <div class="select-overlay"><span class="default">City</span></div>
                            <div class="select-custom">
                                                                                                <span>Bangalore</span>
                                                                                                <span>Punjab</span> 
                                                                                                <span>Delhi</span>
                                                                                                <span>Jaipur</span> 
                                                                                                <span>Lucknow</span>
                                                                                                <span>Chennai</span>
                                                                                                <span>Hyderabad</span>
                                                                                                <span>Kolkata</span> 
                                                                                                <span>Ahmedabad</span>
                                                                                                <span>Baroda</span>  
                                                                                                <span>Mumbai</span> 
                                                                                                <span>Pune</span>   
                                                                                                <span>Surat</span>  
                                                                                                <span>Guwahati</span> 
                                                                                                <span>Coimbatore</span>  
                                                                                                <span>Panjim</span>      
                                                                                                <span>Visakhapatnam</span>     
                            </div>
                        </div>
                        <div class="select-box" id="area-select">
                            <div class="select-overlay"><span class="default">Area</span></div>
                            <div class="select-custom">
                                                                <span class="no-item">Please select a city!</span>
                                                            </div>
                        </div>
                    </div>
                </div>
                <div class="gallery-container">
                    <a class="block-title" href="Gallery.php">Gallery</a>
                    <div class="sidebar-gallery-image">
                        <img src="images/gi mini 1.jpg"/>
                    </div>
                </div>
                <div class="recipe-container">
                    <a class="block-title" href="Recipe.php">Recipes</a>
                    <div class="home-recipe-intro">
                        We love food and we know that you love food too.
                        To help you discover the chef in you, we have dug into the recipe books of  Tadka.
                        We share with you some of our favorite dishes, compliments of the chef!
                    </div>
                    <ul class="home-recipe-links">
                                                <li>
                                                    <a href="recipe1.php" class="recipe-link">Paneer Tikka Lazawab</a>
                        </li>
                                                <li>
                                                    <a href="recipe2.php" class="recipe-link">Coastal Prawns</a>
                        </li>
                                                <li>
                                                    <a href="recipe3.php" class="recipe-link">Dal Makhani</a>
                        </li>
                                                <li>
                                                    <a href="recipe4.php" class="recipe-link">Kadhai Paneer</a>
                        </li>
                                                <li>
                                                    <a class="currsive-link" href="Recipe.php">see all recipes<span class="link-arrow"></span></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-content">
            
<h3 class="page-title">Menu - Soups</h3>

<div>
    We believe in the simple pleasure of eating good food. Food that is fresh, tasty, and is a celebration
    of life in itself. We have a live-grill that is placed directly on your table so that you can grill your
    starters and savour them while they are still sizzling! You can choose from a selection of meat, seafood
    or vegetarian delicacies - we provide all the marinades and sauces that you will need.  And for dinner
    we pamper you with a mouth-watering all-you-can-eat selection.  The soups and salads and main courses are
    taken from cuisines around the world – Mediterranean, American, Oriental, Asian, and yes, even Indian!
    So bring along your family or friends, and your appetite, when you visit any of our restaurants!<br/>
    Menu items subject to availability.
</div>

<ul class="food-top-menu">
        <li class="menu-item  soups-icon">
            <a href="menu-soups.php" class="text">Soups</a>
            <a class="soups-icon icon" href="menu-soups.php"></a>
    </li>
        <li class="menu-item  salads-icon">
            <a href="menu-salads.php" class="text">Salads</a>
            <a class="salads-icon icon" href="menu-salads.php"></a>
    </li>
        <li class="menu-item  starters-icon">
            <a href="menu-starters.php" class="text">Starters</a>
            <a class="starters-icon icon" href="menu-starters.php"></a>
    </li>
        <li class="menu-item active mains-icon">
            <a href="menu-mains.php" class="text">Mains</a>
            <a class="mains-icon icon" href="menu-mains.php"></a>
    </li>
        <li class="menu-item  desserts-icon">
            <a href="menu-desserts.php" class="text">Desserts</a>
            <a class="desserts-icon icon" href="menu-desserts.php"></a>
    </li>
    <li class="resp-menu"><a href="menu-soups.php">Soups</a> </li>
    <li class="resp-menu"><a href="menu-salads.php">Salads</a> </li>
    <li class="resp-menu"><a href="menu-starters.php">Starters</a> </li>
    <li class="resp-menu"><a href="menu-mains.php">Mains</a> </li>
    <li class="resp-menu"><a href="menu-desserts.php">Desserts</a> </li>
    </ul>

    <ul class="food-sub-menu">
        <li><a href="menu-mains.php" class="">VEGETARIAN</a></li>
        <li><a href="non veg mains.php" class="active">NON-VEGETARIAN</a></li>
</ul>

<div class="recipe">
    <img src="images/non veg mains 1.png" class="thumbnail"/>    <img src="images/non veg mains icon.png" class="icon"/>    <div class="desc">
        <h4>Murshidabadi chicken biriyani</h4>
        <em>
            A layered chicken dum biryani made with potatoes and flavoured with ancient Mughal spices.        </em>
    </div>
    <span class="clear-fix"></span>
</div>
<div class="recipe">
    <img src="images/non veg mains 2.png" class="thumbnail"/>    <img src="images/non veg mains icon.png" class="icon"/>    <div class="desc">
        <h4>Dum ke ghost</h4>
        <em>
            Dum cooked mutton made with brown onions.         </em>
    </div>
    <span class="clear-fix"></span>
</div>
<div class="recipe">
    <img src="images/non veg mains 3.png" class="thumbnail"/>    <img src="images/non veg mains icon.png" class="icon"/>    <div class="desc">
        <h4>Crab mangalorian style</h4>
        <em>
            Crab in a Mangalorean chilli paste gravy.         </em>
    </div>
    <span class="clear-fix"></span>
</div>
        </div>
    </div>
</div>
    
     <div class="footer">
    <div class="container">
<div class="message-box">
                     <h4>Send us a quick message</h4>

            <form method="post" action="#" id="contact-form">
                <input type="text" placeholder="Full Name" name="full_name"/> 
                <input type="text" placeholder="Email Id" name="email"/> 
                <input type="text" placeholder="Your Message" class="message" name="message"/>
                <input type="submit" value="Submit">
           </form> 
       </div> 
        <ul class="footer-menu">
            <li><a href="Menu.php">Menu</a></li>
            <li><a href="Locations.php">Locations</a></li>
            <li><a href="Events.php">Events</a></li>
            <li><a href="About Us.php">About us</a></li>
            <li><a href="Gallery.php">Gallery</a></li>
            <li><a href="Recipe.php">Recipes</a></li>
            <!--            <li><a href="#">Contact</a></li>-->
            <li><a href="Pressroom.php">Press</a></li>
            <li><a href="Careers.php">Careers</a></li>
            <li><a href="Contact Us.php">Contact us</a></li>
        </ul>
    </div>
    <div class="footer-flame"></div>
</div>
</body>
</html>