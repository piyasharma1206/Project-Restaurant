<html>
<head>
    <title>Events - Tadka</title>
    
    <link rel="stylesheet" media="all" type="text/css" href="styles/stylesheet.css" />
    <link href="images/icon2.jpg" rel="shortcut icon" type="image/x-icon" >
    
</head>

<body class="events-page">
   <div class="page">
    <div class="container">
        <div class="top-menu-container">
            <ul class="top-right-menu">
                <li>
                            <a href="Pressroom.php" class="">Pressroom</a>
                        </li>
                        <li>
                            <a href="Careers.php" class="">Careers</a>
                        </li>
                        <li>
                            <a href="Contact Us.php" class="">Contact Us</a>
                        </li>
            </ul>
        </div>
        <div class="menu-box">
            <div class="menu-container public-menu-container">

                <ul class="menu">
                    <li class="logo-container">
                        <a href="index.php" class="logo"><img src="images/icon.jpg" alt="Restaurant"/> </a>
                        </li>
                        <li class="menu-collapse">
                            <a href="#" class="explore-nav">Explore <span class="arrow"></span> </a>
                            <ul class="menu-dropdown">
                                <li ><a href="Menu.php" class="text">Menu</a></li>
                                <li ><a href="Locations.php" class="text">Locations</a></li>
                                <li ><a href="Events.php" class="text">Events</a></li>
                                <li ><a href="Our Story.php" class="text">Our Story</a></li>
                                <li ><a href="Gallery.php" class="text">Gallery</a></li>
                                <li ><a href="Recipe.php" class="text">Recipe</a></li>
                                <li ><a href="Pressroom.php" class="text">Pressroom</a></li>
                                <li ><a href="Careers.php" class="text">Careers</a></li>
                                <li>
                                    <ul class="social-links">
                                        <li><a href="#" class="fb-social"></a></li>
                                        <li><a href="#" class="yt-social"></a></li>
                                        <li><a href="#" class="pin-social"></a></li>
                                        <li><a href="#" class="ig-social"></a></li>                                     
                                    </ul>
                            </li>
                        </ul>
                    </li>
                     <li class="menu-item ">
                            <a href="Menu.php" class="text">Menu</a>
                            <a class="menu-icon icon" href="Menu.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Locations.php" class="text">Locations</a>
                            <a class="locations-icon icon" href="Locations.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Events.php" class="text">Events</a>
                            <a class="events-icon icon" href="Events.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Our Story.php" class="text">Our Story</a>
                            <a class="our-story-icon icon" href="Our Story.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Gallery.php" class="text">Gallery</a>
                            <a class="gallery-icon icon" href="Gallery.php"></a>
                        </li>
                        <li class="menu-item ">
                            <a href="Recipe.php" class="text">Recipe</a>
                            <a class="recipe-icon icon" href="Recipe.php"></a>
                        </li>
                        <li>
                            <ul class="social-links">
                                <li><a href="#" class="fb-social"></a></li>
                                <li><a href="#" class="yt-social"></a></li>
                                <li><a href="#" class="pin-social"></a></li>
                                <li><a href="#" class="ig-social"></a></li>
                            </ul>
                    </li>
                </ul>
                <div class="search-box">
                    <div class="search-container">
                        <div class="search-heading">Locations close to you:</div>
                                                                        <div class="select-box" id="city-select">
                            <div class="select-overlay"><span class="default">City</span></div>
                            <div class="select-custom">
                                                                                                <span>Bangalore</span>                                                                <span>Punjab</span>                                                                <span>Delhi</span>                                                                <span>Jaipur</span>                                                                <span>Lucknow</span>                                                                <span>Chennai</span>                                                                <span>Hyderabad</span>                                                                <span>Kolkata</span>                                                                <span>Ahmedabad</span>                                                                <span>Baroda</span>                                                                <span>Mumbai</span>                                                                <span>Pune</span>                                                                <span>Surat</span>                                                                <span>Guwahati</span>                                                                <span>Coimbatore</span>                                                                <span>Panjim</span>                                                                <span>Visakhapatnam</span>                                                                <span>Raipur</span>                                                                <span>Mysuru</span>                                                                                            </div>
                        </div>
                        <div class="select-box" id="area-select">
                            <div class="select-overlay"><span class="default">Area</span></div>
                            <div class="select-custom">
                                                                <span class="no-item">Please select a city!</span>
                                                            </div>
                        </div>
                    </div>
                </div>
                <div class="gallery-container">
                    <a class="block-title" href="Gallery.php">Gallery</a>
                    <div class="sidebar-gallery-image">
                        <img src="images/gallery image 11.jpg"/>
                    </div>
                </div>
                <div class="recipe-container">
                    <a class="block-title" href="Recipe.php">Recipes</a>
                    <div class="home-recipe-intro">
                        We love food and we know that you love food too.
                        To help you discover the chef in you, we have dug into the recipe books of Tadka.
                        We share with you some of our favorite dishes, compliments of the chef!
                    </div>
                    <ul class="home-recipe-links">
                                                <li>
                                                    <a href="recipe1.php" class="recipe-link">Paneer Tikka Lazawab</a>
                        </li>
                                                <li>
                                                    <a href="recipe2.php" class="recipe-link">Coastal BBQ Prawns</a>
                        </li>
                                                <li>
                                                    <a href="recipe3.php" class="recipe-link">Dal Makhani</a>
                        </li>
                                                <li>
                                                    <a href="recipe4.php" class="recipe-link">Kadhai Paneer</a>
                        </li>
                                                <li>
                                                    <a class="currsive-link" href="Recipe.php">see all recipes<span class="link-arrow"></span></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-content">
            <h3 class="page-title">Events</h3>
    <div class="event">
        <img src="images/events image.png" class="event-thumb"/>
        <h3 class="event-title"><a href="event africa.php">AFRICA MAGICA</a></h3>
        
        <div class="description">Tadka PRESENTS ‘AFRICA MAGICA’ – THE AFRICAN FOOD FESTIVAL
            
Witness the wild side at Tadka with flavor’s from Africa. 
This summer, take the African Safari through the wild jungles, as Africa comes alive at Tadka with ‘Africa Magica’ – the African food festival.
Get a chance to experience the magic of the mysterious and feral African Signature dishes include Kuku Paka, Tanzanian Shabbat Fish, belafonte prawns, Piri Piri Tangdi.
Get swept away by equally tantalizing vegetarian preparations such as Butternut and Shallot Soup, Couscous Stuffed Tomatoes, congo paneer steak.
Also on the menu are beverages with exotic names inspired by Africa which include Jungle Safari Sangria and West African Iced Chocolate Drink.
With this African food festival, Tadka is all revved up to let diners take a walk on the wild side.
Visiting guests will be welcomed to a bright and vibrant atmosphere.
Keep a look out for rustic old hatari jeeps – an element that is sure to complete your African adventure.
This special food menu offers a chance to go wild over African food.
The African menu preparations, complemented with starters and soups are here to enable a wonderful barbeque experience to the guests. 
We look forward to cater to the tastes of our diners and truly revel in the spirit of Africa.”
        </div>

        
        <div class="meta"> 10th April to 30th April <br /> 
             
        </div>
        
        <div class="share-box">
            
        </div>

    </div>

        </div>
    </div>
</div>

    <div class="footer">
        <div class="container">
                   <div class="message-box">
                     <h4>Send us a quick message</h4>

            <form method="post" action="#" id="contact-form">
                <input type="text" placeholder="Full Name" name="full_name"/> 
                <input type="text" placeholder="Email Id" name="email"/> 
                <input type="text" placeholder="Your Message" class="message" name="message"/>
                <input type="submit" value="Submit">
           </form> 
       </div> 
            <ul class="footer-menu">
                <li><a href="Menu.php">Menu</a></li>
                <li><a href="Locations.php">Locations</a></li>
                <li><a href="Events.php">Events</a></li>
                <li><a href="About Us.php">About us</a></li>
                <li><a href="Gallery.php">Gallery</a></li>
                <li><a href="Recipe.php">Recipes</a></li>
                <li><a href="Pressroom.php">Press</a></li>
                <li><a href="Careers.php">Careers</a></li>
                <li><a href="Contact Us.php">Contact us</a></li>
            </ul>
        </div>
        <div class="footer-flame"></div>
    </div>
    
</body>
</html>

 
